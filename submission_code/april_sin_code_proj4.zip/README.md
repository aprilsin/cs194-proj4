# Project 04: Face Detection

Name: April Sin
SID: 3035168618

### Requirements:

Danes dataset images should to be under "data/imm_face_db/"
IBug dataset images and xml files should be under "data/ibug_300W_large_face_landmark_dataset/"
Custom images will be under "data/my_collection/". A corresponding xml file needs to be present, and it should be named "my_samples.xml"

### Instructions:

To run the code, run each cell in the iPython notebook of `main.ipynb`.
